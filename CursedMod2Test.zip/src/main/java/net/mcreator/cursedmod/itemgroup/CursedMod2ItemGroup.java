
package net.mcreator.cursedmod.itemgroup;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;

import net.mcreator.cursedmod.item.NothignItem;
import net.mcreator.cursedmod.CursedModModElements;

@CursedModModElements.ModElement.Tag
public class CursedMod2ItemGroup extends CursedModModElements.ModElement {
	public CursedMod2ItemGroup(CursedModModElements instance) {
		super(instance, 2);
	}

	@Override
	public void initElements() {
		tab = new ItemGroup("tabcursed_mod_2") {
			@OnlyIn(Dist.CLIENT)
			@Override
			public ItemStack createIcon() {
				return new ItemStack(NothignItem.block);
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
	public static ItemGroup tab;
}
